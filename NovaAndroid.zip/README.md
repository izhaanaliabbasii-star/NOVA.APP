# Nova — Siri-style Android Assistant

A voice assistant for Android: tap the mic (or say "Nova" once set up),
speak, and Nova replies out loud. It opens apps, searches YouTube,
toggles settings, and answers anything via Gemini.

## 1. Build & run
1. Install **Android Studio** (free): https://developer.android.com/studio
2. File > Open > select this `NovaAndroid` folder. Let Gradle sync finish.
3. Connect your phone with USB debugging ON (or use an emulator with a mic),
   then press the **Run** ▶ button.

## 2. Add your Gemini brain (required for answering questions)
1. Get a FREE API key: https://aistudio.google.com/app/apikey
2. Open Nova > paste key > Save keys.

## 3. Try it (tap the big button and say)
- "open WhatsApp" / "open YouTube" / "open Spotify"
- "play lofi beats"  (opens YouTube search)
- "turn on wifi" / "open bluetooth settings"
- "what is the capital of France?" / any question (Gemini answers)

## 4. "Hey Nova" wake word (optional, works offline)
Custom wake-word files are licensed per-user, so this is a 5-min one-time setup:
1. Free account at https://console.picovoice.ai
2. Porcupine > Train a custom keyword "nova", platform **Android** > download
3. Rename the file to `nova.ppn`, put it in `app/src/main/assets/` (create the folder)
4. Copy your Picovoice Access Key into the app > Save > restart
Now saying "Nova" anywhere makes it reply "Yes?" and start listening.

## 5. Add live weather (optional)
1. Free key: https://openweathero­rmap.org/api (or use weatherapi.com)
2. Edit `CommandProcessor.kt` — the `if (t.contains("weather"))` block —
   and call the API with OkHttp (same pattern as GeminiClient).

## v1.8 — the FULL 4-stage cinematic intro, matching Jarvis's desktop version exactly
Replaced the single simple screen from v1.7 with all 4 real stages from Jarvis's `cinematic_setup.py`,
adapted for a phone (same structure, Nova's purple instead of Jarvis's orange):
1. **System scan** — typewriter log: "Scanning device... ✓ Microphone found... Looking for an AI
   provider... ✕ No provider configured yet."
2. **Select Primary Intelligence** — a Gemini card ("★★★★★ Recommended") and a "Set up later" card,
   just like Jarvis's Gemini-vs-OpenRouter choice screen.
3. **Paste key + authenticate** — a password-masked key field that auto-triggers a fake
   "authenticating" progress-bar animation once you've typed more than 10 characters, ending in
   "✓ Identity Verified / Ready" — then dissolves into "Identity confirmed. Hello. I'm Nova. Ready
   whenever you are." with a "Launch Nova →" button, exactly like Jarvis's "Hello. I'm Jarvis." beat.
4. **Ignition sequence** — "Establishing Neural Link..." with modules ticking in one at a time
   (VOICE, MEMORY, VISION, AUTOMATION, REASONING — Jarvis's list was similar), ending in "Neural Link
   Established." before handing off to the main screen.
Still only shown once; skip anywhere via "Set up later," and every key can still be edited afterward
from the main screen.

## v1.9 — fixed a real 1-2 second lag bug
**Android's speech recognizer defaults to waiting ~2 seconds of silence after you stop talking**
before it decides you're done and hands the text back — that alone was eating most of any
"respond in 3 seconds" budget, before Gemini even gets involved. Fixed in `VoiceEngine.kt`:
trimmed the silence wait down to 900ms, and turned on offline-first recognition (skips a network
round trip for the speech-to-text step where the device supports it, falls back to online
automatically where it doesn't).

**Honest limits on speed, not glossed over:**
- Local commands (open app, flashlight, wifi, DND, brightness, battery) were already near-instant —
  no network involved at all, this fix doesn't change those.
- Anything routed to Gemini (open-ended questions, presentations) still depends on your internet
  connection and Google's server response time — typically 1–2 seconds with the fast model this
  uses, but that's not something any app, including this one, can force to a fixed number every
  single time. A bad connection will always be a bad connection.

## v1.8 — full 4-stage Jarvis-style boot sequence
v1.7's onboarding was just stage 1 of Jarvis's actual desktop flow. Now all four stages are ported:
1. **System scan** — typewriter log ("Scanning device... ✓ Microphone found...")
2. **Select Primary Intelligence** — a Gemini card to tap (styled like Jarvis's provider-picker)
3. **Paste your key** — pasting it triggers a fake "Authenticating..." bar-fill animation
   (purely cosmetic, like Jarvis's), ending in "✓ Identity Verified" then "Hello. I'm Nova. Ready
   whenever you are." with a Launch button
4. **Establishing Neural Link** — MEMORY / VOICE / VISION / AUTOMATION / REASONING power up one
   at a time, ending "Neural Link Established," then it hands off to the main screen

"Skip for now" is available at two points if you'd rather add the key later from the main screen.
Runs once, ever, per install.

## v1.7 — proper first-run intro screen (inspired by Jarvis's desktop onboarding)
Jarvis's desktop version has a whole cinematic "reactor" boot-up animation before it asks for your
API key. Nova now has its own version, built for a phone: on first launch it shows a pulsing glow
ring, a typewriter-style scan log ("Scanning device... ✓ Microphone found... Looking for an AI
provider..."), then reveals a single field for your Gemini key with a direct link to get one free,
plus a "Skip for now" option. It only shows once — after that it goes straight to the main screen,
and you can still change any key later from there. New files: `OnboardingActivity.kt`,
`ReactorView.kt` (the pulsing ring, drawn with Canvas — no image assets needed),
`activity_onboarding.xml`. `OnboardingActivity` is now the launcher activity instead of `MainActivity`.

## v1.6 — background wake word, continuous conversation, file search, spam flagging, battery health
**"Say Nova without opening the app" — now real, with one unavoidable catch:**
Toggle "Listen for 'Nova' even when the app is closed" on the home screen and Nova runs as a
background service that keeps listening even with the app closed or phone locked. The catch:
Android *requires* a permanent notification for any app doing background microphone work — that's
a hard OS privacy rule, not something Nova can hide (Siri and Google Assistant both work around this
by being baked into the OS itself, which a third-party app can't do). Also: some phones (Xiaomi,
Samsung, OnePlus especially) aggressively kill background services to save battery — if it stops
responding after a while, add Nova to "unrestricted battery usage" in phone Settings.

**"Talk to him nonstop like Siri"** — done. After Nova replies, it keeps listening immediately
instead of waiting for the wake word again, so you can have a real back-and-forth. It ends naturally
when you go quiet for a few seconds, or you say "stop"/"that's all"/"goodbye".

**🗂️ File manager** — "find my pdf [name]" / "find file [name]" searches your device storage.
Needs the "Enable file search" button tapped once (Android's "All files access" permission — a
special one Google requires you grant manually via Settings, not a normal popup).

**📞 Spam call detection** — real, but a heuristic, not a database: tap "Enable spam call flagging"
to make Nova your call-screening app, and it'll notify you when a call comes in from a number NOT in
your contacts. It does NOT block anything automatically (too many false positives — delivery
drivers, doctors' offices, new numbers) and it is NOT checking against an actual spam database like
Truecaller, since that needs a paid third-party API this project doesn't have.

**🔋 Battery health monitor** — "battery" reports charge %, charging status, temperature, and
Android's OS-level health flag (Good/Overheat/Cold/Dead/etc). One honest limit: Android does **not**
expose a numeric "battery health %" (like iOS's "Maximum Capacity") through any public API — that
number literally doesn't exist to read on stock Android, so this reports everything that *is*
actually available instead.

**Still can't avoid an API key** — Gemini (the brain) and the optional YouTube key both come from
Google. No app, including this one, can make that requirement disappear without someone paying for
a shared key on everyone's behalf, which isn't something this project does.

## v1.5 — fixed a real crash bug
**"call [name]" or "message [name]" would crash the whole app** if you hadn't granted Contacts
permission yet (or denied it) — `ContactLookup` queried your contacts without checking permission
first, and an unhandled `SecurityException` on that background thread kills the entire app process,
which is what looks like a "freeze." Fixed: it now checks permission first and fails gracefully with
a spoken message instead of crashing. Everything else (open app, weather, screen scan) was already
safe — they either need no permission (open app) or already checked it before use (weather, screen
scan's mandatory system dialog).

## v1.4 — real calling, contact-based messaging, YouTube autoplay, 1,440 presentation designs
**Fixed a real bug:** the presentation-content prompt had a broken/unescaped quote that would have
stopped the whole app from compiling. Fixed.

**New/upgraded:**
- **"call [contact name or number]"** -> places a real phone call (needs Call permission, which the
  app now asks for on first launch; falls back to opening the dialer pre-filled if you say no).
- **"whatsapp/message/text [contact name or number] [message]"** -> now looks the name up in your
  contacts first, so it opens the right person's chat pre-filled.
- **"play [song/video]"** -> now plays the actual top result immediately instead of just opening a
  search list — needs a free YouTube Data API v3 key pasted into the app (new field on the home
  screen); without a key it still falls back to opening search results.
- **Presentation designs: 1,440 combos** now (was 72) — 12 palettes x light/dark x 3 layouts x
  4 accent-brightness shifts x 5 heading fonts, still deterministic per topic.
- **"brightness up/down/[N]%"** now actually changes the screen brightness value, not just opens
  the settings page.

**Still not real, and why:**
- **Declining/auto-answering incoming phone calls** — Android locks this down hard; it requires your
  app to become the default Phone app or get the CallScreeningService role, both of which need a
  Play Store review process, not just a permission grant. Doable as a bigger follow-up if you want it.
- Everything listed as "not portable" in v1.3 (MS Paint automation, Playwright, Discord bot, etc.) —
  still Windows-only, still can't run on Android.

## v1.3 — ported from Jarvis (desktop AI): memory, reminders, messaging, weather, more
**New commands:**
- **"remember [anything]"** -> stores it; **"what do you remember about X"** / **"do you remember X"** -> recalls it;
  "list everything you remember" -> dumps it all; "forget everything" -> wipes it. Survives app restarts.
- **"remind me to [task] in [N] minutes/hours"** or **"remind me to [task] at [time]"** -> real Android notification
  fires at that time, even if the app is closed.
- **"whatsapp/message/text [contact or number] [message]"** -> opens WhatsApp with the message pre-filled
  (Android won't let apps silently auto-send on your behalf — you tap send).
- **"weather"** -> now actually works, no API key needed (uses your last known location + the free Open-Meteo API).
- **"log [habit]"** (e.g. "log pushups") -> counts it for today; **"how many [habit] today"** -> reads the count back.
- **"add event [title] at [time]"** / **"schedule [title] at [time]"** -> opens your calendar app pre-filled to confirm.
- **"flashlight on/off"**, **"do not disturb on/off"**, **"brightness"** (opens display settings).
- **"search for X"** / **"google X"** -> web search; **"play X on spotify"** -> searches Spotify.

**Not ported from Jarvis (Windows-desktop-only, can't work on Android as-is):**
MS Paint drawing, Playwright browser automation, auto-answer/decline calls inside desktop apps, the Qt UI,
webcam push-up counter, a persistent Discord bot, a full website builder, and the autonomous dev-agent —
these all depend on Windows window automation, a webcam pose-tracking model, or a server that's always running.

## Roadmap (not included yet — say the word and I'll add)
- [ ] Runs from any screen (foreground service + default-assistant hook)
- [ ] Full phone control (taps/swipes/scroll via AccessibilityService)
- [ ] Live weather
- [ ] Make presentations (needs a small backend server — phones can't run python-pptx)
- [ ] Gemini Live API for real-time two-way voice (interruptible, like Siri)

## How it works
SpeechRecognizer (your voice -> text)
  -> CommandProcessor handles phone commands locally,
     everything else goes to GeminiClient (text -> answer)
  -> TextToSpeech speaks the reply
WakeWordManager (Porcupine) listens for "Nova" 24/7, fully offline.

## v1.1 fixes (use this version!)
- **"Yes?" is actually heard now** — before, the mic started at the same instant and cut it off
- **Mic fight fixed** — wake word engine and speech recognizer no longer grab the microphone at the same time (this was the "he pauses / doesn't answer / gets stuck" bug)
- **Nova goes back to listening for "Nova" after every reply** (before it sometimes stayed asleep)
- **Clearer error messages** — now tells you exactly what's wrong (no internet, mic busy, no permission, nothing heard)
- **Can't double-start the mic** anymore

### "Can he hear?" quick checklist
1. Mic permission allowed? (Settings > Apps > Nova > Permissions)
2. Internet ON — Android's speech recognition runs through Google's service on most phones
3. Google app installed & enabled (that's the speech engine)
4. Speak right after the "Listening..." prompt appears
5. Kill and restart the app after saving keys

## v1.2 — presentations + screen scan + speed
**New commands:**
- "make a presentation about electric cars, 30 slides" -> builds a real .pptx
  (saved to Downloads/Nova, opens automatically). 72 design combos
  (12 palettes x light/dark x 3 layouts), same topic = same design.
  No PC needed — the PPTX is built on the phone from scratch.
- "scan screen" / "what's on my screen" / "read my screen" -> Nova looks at your
  screen and answers (Android will ask a one-time permission dialog by Google
  policy — nothing can skip it). One frame, sent to Gemini, nothing stored.

**Speed:** status line now shows reply time ("Nova (2.1s): ...").
Local commands (open app, settings) = instant. Gemini answers = 1-4s on wifi.

**Fixes:** mic could never get permanently stuck again (crash guard + busy guard),
utterance IDs can't collide.

## Play Store? Read this first
As-is: perfect as a personal sideload app (install APK directly).
To publish on Play Store you MUST fix these:
1. **QUERY_ALL_PACKAGES** — Google restricts it; personal apps get rejected.
   Fix: replace with a <queries> block or a fixed app-name -> package map.
2. **Picovoice wake word** — the free Porcupine tier is PERSONAL USE ONLY.
   A Play Store build needs a paid Picovoice license, or ship without wake word.
3. **Gemini key inside the app** — anyone can extract it and drain your quota.
   Fix: route calls through a small backend proxy, or restrict the key
   (API restrictions + Firebase App Check).
4. You need a **privacy policy** (you record audio) and the
   **media projection disclosure** for screen scan.

## Test checklist (run these one by one on your phone)
1. [ ] App opens, "Ready" shows
2. [ ] Tap Talk -> "Listening..." -> say "hello" -> Nova speaks back (check time in status)
3. [ ] "open YouTube" -> YouTube opens
4. [ ] "turn on wifi" -> wifi settings opens
5. [ ] "play lofi beats" -> YouTube search opens
6. [ ] "make a presentation about space, 6 slides" -> file appears in Downloads/Nova
7. [ ] "scan screen" -> permission dialog -> Start -> Nova describes your screen
8. [ ] Say "Nova" (after wake word setup) -> hears "Yes?" -> give a command
9. [ ] Rapid-fire: tap Talk 3 times fast -> no crash, friendly message
10. [ ] Rotate phone / lock screen while replying -> no freeze when back

If anything fails, tell me the EXACT status text + phone model + Android version.
