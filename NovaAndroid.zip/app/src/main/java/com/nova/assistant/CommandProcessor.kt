package com.nova.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import java.util.Locale

/**
 * Handles phone-control commands locally (fast + free, no AI needed).
 * Returns a spoken reply, or null if the command is not recognized
 * (then it gets sent to Gemini instead).
 */
object CommandProcessor {

    fun tryHandle(ctx: Context, raw: String): String? {
        val t = raw.lowercase(Locale.ROOT).trim()

        // presentations: "make a presentation about X, 30 slides"
        if (t.contains("presentation") || t.contains("powerpoint")
            || (t.contains("slides") && (t.startsWith("make") || t.startsWith("create")))) {
            val key = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
                .getString("gemini_key", "") ?: ""
            return PresentationMaker.handle(ctx, key, raw)
        }

        if (t.startsWith("open ") && t.length > 5) {
            return openApp(ctx, t.removePrefix("open ").trim())
        }
        if (t.contains("youtube") || t.contains("search video")
            || (t.startsWith("play ") && !t.contains("spotify") && !t.contains("song"))) {
            val query = t.replace("play", "").replace("youtube", "").replace("on", "").trim()
            return YoutubeClient.playTop(ctx, query.ifBlank { "trending" })
        }
        if (t.contains("wifi") || t.contains("bluetooth") || t == "settings"
            || t.contains("phone settings")) {
            return openSettings(ctx, t)
        }
        if (t.contains("weather")) {
            return WeatherClient.getWeather(ctx)
        }

        // reminders: "remind me to X in N minutes" / "remind me to X at 5pm"
        ReminderManager.tryHandle(ctx, t)?.let { return it }

        // calling: "call/phone/dial <name or number>"
        PhoneDialer.tryHandle(ctx, raw)?.let { return it }

        // messaging: "whatsapp/message/text <contact> <message>"
        MessageSender.tryHandle(ctx, raw)?.let { return it }

        // grab-bag: flashlight, DND, brightness, calendar, web search,
        // spotify, memory (remember/recall), habit logging
        SystemActions.tryHandle(ctx, raw)?.let { return it }

        return null  // not a local command -> ask Gemini
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val packages = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0))
        } else {
            pm.getInstalledPackages(0)
        }
        for (pi in packages) {
            val appInfo = pi.applicationInfo ?: continue
            val label = appInfo.loadLabel(pm)?.toString()?.lowercase(Locale.ROOT) ?: continue
            if (label.contains(name)) {
                val launch = pm.getLaunchIntentForPackage(pi.packageName)
                if (launch != null) {
                    ctx.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    return "Opening " + appInfo.loadLabel(pm) + "."
                }
            }
        }
        return "I couldn't find an app called " + name + "."
    }

    private fun searchYouTube(ctx: Context, query: String): String {
        val q = query.ifBlank { "videos" }
        val intent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra(Intent.EXTRA_QUERY, q)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            "Sure, here you go."
        } catch (e: ActivityNotFoundException) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "YouTube app not found, opening the browser instead."
        }
    }

    private fun openSettings(ctx: Context, t: String): String {
        val intent = when {
            t.contains("wifi") -> Intent(Settings.ACTION_WIFI_SETTINGS)
            t.contains("bluetooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "Done."
    }
}
