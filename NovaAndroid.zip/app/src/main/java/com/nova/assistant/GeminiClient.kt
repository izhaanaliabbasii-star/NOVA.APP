package com.nova.assistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Nova's brain. Sends text (optionally + an image) to Gemini and returns
 * a short spoken-style reply. Free key: https://aistudio.google.com/app/apikey
 */
object GeminiClient {
    private const val MODEL = "gemini-2.0-flash"
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)     // long replies (presentations) need this
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        // HTTP/2 keep-alive is on by default -> repeat commands feel instant
        .build()
    private val JSON = "application/json; charset=utf-8".toMediaType()

    private const val SYSTEM_PROMPT =
        "You are Nova, a friendly voice assistant living on an Android phone. " +
        "Reply in a spoken, conversational style. Keep answers under 2 sentences " +
        "unless the user clearly asks for more detail. No markdown, no bullet points."

    /** Simple question. Returns the reply text. */
    fun ask(apiKey: String, userText: String): String =
        call(apiKey, userText, null)

    /** Question about an image (screen scan). jpegBase64 = base64-encoded JPEG. */
    fun askWithImage(apiKey: String, userText: String, jpegBase64: String): String =
        call(apiKey, userText, jpegBase64)

    private fun call(apiKey: String, userText: String, imageBase64: String?): String {
        if (apiKey.isEmpty()) return "Add your Gemini API key in the app first."

        val parts = JSONArray()
        if (imageBase64 != null) {
            parts.put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", imageBase64)))
        }
        parts.put(JSONObject().put("text", userText))

        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT))))
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))

        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/" +
                    MODEL + ":generateContent?key=" + apiKey)
            .post(body.toString().toRequestBody(JSON))
            .build()

        return try {
            client.newCall(request).execute().use { resp ->
                val raw = resp.body?.string() ?: "{}"
                val json = JSONObject(raw)
                if (!resp.isSuccessful) {
                    val err = json.optJSONObject("error")?.optString("message") ?: "unknown error"
                    "Gemini API error: " + err
                } else {
                    json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                        .trim()
                }
            }
        } catch (e: Exception) {
            "Network error: " + (e.message ?: "unknown")
        }
    }
}
