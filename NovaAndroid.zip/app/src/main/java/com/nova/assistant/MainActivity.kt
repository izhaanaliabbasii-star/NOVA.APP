package com.nova.assistant

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.SystemClock
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var statusText: TextView
    private lateinit var voice: VoiceEngine
    private var wakeWordManager: WakeWordManager? = null
    private var pendingScanPrompt: String? = null

    companion object {
        private const val REQ_MIC = 1
        private const val REQ_PROJECTION = 2
        private const val REQ_CALL_SCREENING_ROLE = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("nova", MODE_PRIVATE)
        statusText = findViewById(R.id.statusText)

        val geminiInput: EditText = findViewById(R.id.geminiKeyInput)
        val porcupineInput: EditText = findViewById(R.id.porcupineKeyInput)
        val youtubeInput: EditText = findViewById(R.id.youtubeKeyInput)
        geminiInput.setText(prefs.getString("gemini_key", ""))
        porcupineInput.setText(prefs.getString("porcupine_key", ""))
        youtubeInput.setText(prefs.getString("youtube_key", ""))

        findViewById<Button>(R.id.saveKeysButton).setOnClickListener {
            prefs.edit()
                .putString("gemini_key", geminiInput.text.toString().trim())
                .putString("porcupine_key", porcupineInput.text.toString().trim())
                .putString("youtube_key", youtubeInput.text.toString().trim())
                .apply()
            Toast.makeText(this, "Keys saved. Restart app to activate wake word.",
                Toast.LENGTH_SHORT).show()
        }

        voice = VoiceEngine(
            context = this,
            onReadyCallback = { status("Ready. Tap Talk and speak — or just say \"Nova\".") },
            onListeningCallback = { status("Listening...") },
            onHeardCallback = { handleUserText(it) },
            onErrorCallback = { msg ->
                status(msg)
                wakeWordManager?.resume()
            }
        )

        findViewById<Button>(R.id.talkButton).setOnClickListener {
            if (hasMicPermission()) voice.listen() else requestMicPermission()
        }

        // ---- background wake-word toggle ----
        val bgSwitch: Switch = findViewById(R.id.backgroundListenSwitch)
        bgSwitch.isChecked = prefs.getBoolean(NovaBackgroundService.PREF_ALWAYS_LISTEN, false)
        bgSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(NovaBackgroundService.PREF_ALWAYS_LISTEN, checked).apply()
            val serviceIntent = Intent(this, NovaBackgroundService::class.java)
            if (checked) {
                wakeWordManager?.stop()  // avoid two things fighting for the mic
                wakeWordManager = null
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(serviceIntent) else startService(serviceIntent)
                status("Nova will now listen for \"Nova\" even with the app closed.")
            } else {
                stopService(serviceIntent)
                status("Background listening off.")
                startWakeWordIfConfigured()
            }
        }

        // ---- file search permission ----
        findViewById<Button>(R.id.fileAccessButton).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 30 && !Environment.isExternalStorageManager()) {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                Toast.makeText(this, "File search already enabled.", Toast.LENGTH_SHORT).show()
            }
        }

        // ---- spam call flagging role ----
        findViewById<Button>(R.id.spamRoleButton).setOnClickListener {
            if (Build.VERSION.SDK_INT >= 29) {
                val roleManager = getSystemService(RoleManager::class.java)
                if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                    if (roleManager.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
                        Toast.makeText(this, "Spam call flagging already enabled.", Toast.LENGTH_SHORT).show()
                    } else {
                        startActivityForResult(
                            roleManager.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),
                            REQ_CALL_SCREENING_ROLE
                        )
                    }
                } else {
                    Toast.makeText(this, "This device doesn't support call screening roles.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Spam call flagging needs Android 10 or newer.", Toast.LENGTH_SHORT).show()
            }
        }

        // answer comes back from the screen-scan service
        ScreenScanService.onResult = { reply ->
            runOnUiThread {
                status("Nova: " + reply)
                voice.speak(reply) { voice.listen() }  // keep the conversation going
            }
        }

        if (hasMicPermission() && !prefs.getBoolean(NovaBackgroundService.PREF_ALWAYS_LISTEN, false)) {
            startWakeWordIfConfigured()
        } else if (!hasMicPermission()) {
            requestMicPermission()
        } else {
            status("Nova is listening in the background — say \"Nova\" any time.")
        }
    }

    private fun handleUserText(text: String) {
        val t = text.lowercase()
        status("You: " + text)

        // "stop" / "goodbye" / etc -> end the back-and-forth, go back to wake word
        if (ConversationUtil.isExitPhrase(t)) {
            voice.speak("Okay, just say \"Nova\" when you need me.") { wakeWordManager?.resume() }
            return
        }

        // screen scan commands go through the projection flow
        if (t.contains("scan screen") || t.contains("what's on my screen")
            || t.contains("whats on my screen") || t.contains("look at my screen")
            || t.contains("read my screen")) {
            startScreenScan(text)
            return
        }

        val key = prefs.getString("gemini_key", "") ?: ""
        val started = SystemClock.elapsedRealtime()
        Thread {
            val reply = CommandProcessor.tryHandle(this, text)
                ?: GeminiClient.ask(key, text)
            val took = (SystemClock.elapsedRealtime() - started) / 1000.0
            runOnUiThread {
                status("Nova (" + String.format("%.1f", took) + "s): " + reply)
                voice.speak(reply) {
                    // Continuous conversation: keep listening right away instead of
                    // requiring the wake word again each time — like talking to Siri.
                    // It naturally ends when you go quiet (speech-timeout error below
                    // resumes wake-word mode) or say an exit phrase like "stop".
                    voice.listen()
                }
            }
        }.start()
    }

    // ================= SCREEN SCAN =================
    private fun startScreenScan(prompt: String) {
        pendingScanPrompt = prompt
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CALL_SCREENING_ROLE) {
            val granted = resultCode == RESULT_OK
            Toast.makeText(this,
                if (granted) "Spam call flagging enabled." else "Not enabled.",
                Toast.LENGTH_SHORT).show()
            return
        }
        if (requestCode == REQ_PROJECTION) {
            if (resultCode == RESULT_OK && data != null) {
                status("Scanning screen...")
                val service = Intent(this, ScreenScanService::class.java).apply {
                    putExtra(ScreenScanService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenScanService.EXTRA_RESULT_DATA, data)
                    putExtra(ScreenScanService.EXTRA_PROMPT,
                        pendingScanPrompt ?: "Describe what is on this screen.")
                }
                startForegroundService(service)
            } else {
                status("Screen scan cancelled.")
                wakeWordManager?.resume()
            }
        }
    }

    // ================= WAKE WORD =================
    private fun startWakeWordIfConfigured() {
        val key = prefs.getString("porcupine_key", "") ?: ""
        if (key.isEmpty()) {
            status("Tip: add a Picovoice key + nova.ppn file for hands-free wake word.")
            return
        }
        wakeWordManager = WakeWordManager(this, key,
            onWake = {
                runOnUiThread {
                    wakeWordManager?.pause()
                    voice.speak("Yes?") {
                        if (!voice.isListening) voice.listen()
                    }
                }
            },
            onError = { msg -> runOnUiThread { status("Wake word off: " + msg) } }
        ).also { it.start() }
    }

    private fun hasMicPermission() =
        ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED

    private fun requestMicPermission() =
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.ACCESS_COARSE_LOCATION,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS
            ),
            REQ_MIC
        )

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startWakeWordIfConfigured()
        }
    }

    private fun status(s: String) { runOnUiThread { statusText.text = s } }

    override fun onDestroy() {
        wakeWordManager?.stop()
        voice.shutdown()
        super.onDestroy()
    }
}
