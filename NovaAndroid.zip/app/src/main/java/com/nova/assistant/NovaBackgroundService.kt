package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.IBinder

/**
 * Runs "Hey Nova" wake-word listening even when the app is closed / phone is
 * locked. Android REQUIRES a persistent, visible notification for any app
 * doing background mic work (this cannot be hidden — it's a privacy
 * protection, not a Nova choice, same reason Siri shows a mic indicator).
 *
 * Battery note: Porcupine is built for exactly this (low-power always-on
 * wake word), but Android's own battery optimization / OEM task-killers
 * (especially Xiaomi, Samsung, OnePlus) may still kill background services
 * after a while — if wake word stops working after some hours, add Nova to
 * "unrestricted battery usage" in Settings > Apps > Nova > Battery.
 */
class NovaBackgroundService : Service() {

    companion object {
        const val CHANNEL_ID = "nova_background"
        const val NOTIF_ID = 42
        const val PREF_ALWAYS_LISTEN = "always_listen"
    }

    private var wakeWordManager: WakeWordManager? = null
    private var voice: VoiceEngine? = null
    private lateinit var prefs: SharedPreferences

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("nova", MODE_PRIVATE)
        startForeground(NOTIF_ID, buildNotification("Listening for \"Nova\"..."))

        voice = VoiceEngine(
            context = this,
            onReadyCallback = {},
            onListeningCallback = { updateNotification("Listening...") },
            onHeardCallback = { text -> handleHeard(text) },
            onErrorCallback = { updateNotification("Listening for \"Nova\"..."); wakeWordManager?.resume() }
        )

        val key = prefs.getString("porcupine_key", "") ?: ""
        if (key.isNotBlank()) {
            wakeWordManager = WakeWordManager(this, key,
                onWake = {
                    wakeWordManager?.pause()
                    voice?.speak("Yes?") { voice?.listen() }
                },
                onError = { msg -> updateNotification("Wake word off: $msg") }
            ).also { it.start() }
        } else {
            updateNotification("Add a Picovoice key in Nova to enable background wake word.")
        }
    }

    private fun handleHeard(text: String) {
        if (ConversationUtil.isExitPhrase(text)) {
            voice?.speak("Okay.") { wakeWordManager?.resume() }
            return
        }
        val key = prefs.getString("gemini_key", "") ?: ""
        Thread {
            val reply = CommandProcessor.tryHandle(this, text) ?: GeminiClient.ask(key, text)
            voice?.speak(reply) { voice?.listen() }  // keep the conversation going
        }.start()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY  // restart if the OS kills it (memory pressure, not user-stopped)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        wakeWordManager?.stop()
        voice?.shutdown()
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Nova background listening", NotificationManager.IMPORTANCE_LOW)
            )
        }
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Nova")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_launcher)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
