package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Base64
import android.util.DisplayMetrics
import java.io.ByteArrayOutputStream
import kotlin.concurrent.thread

/**
 * "scan screen" -> Nova looks at your screen and answers about it.
 *
 * Android shows a one-time "Start recording/capture?" dialog (by Google policy,
 * nothing can skip it). After you tap Start, Nova grabs ONE screenshot,
 * sends it to Gemini, speaks the answer, and stops. Nothing is stored.
 */
class ScreenScanService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "data"
        const val EXTRA_PROMPT = "prompt"
        /** MainActivity sets this to receive the spoken answer (or error). */
        @Volatile var onResult: ((String) -> Unit)? = null
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        @Suppress("DEPRECATION")
        val data = intent?.getParcelableExtra<Intent>(EXTRA_RESULT_DATA)
        val prompt = intent?.getStringExtra(EXTRA_PROMPT)
            ?: "Describe what is on this screen in one or two sentences."

        if (resultCode == 0 || data == null) {
            onResult?.invoke("Screen scan cancelled.")
            stopSelf()
            return START_NOT_STICKY
        }

        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)

        // Android 14+ requires a callback registered
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { cleanup() }
        }, Handler(Looper.getMainLooper()))

        // capture at half resolution - fast upload, plenty for understanding
        val metrics = DisplayMetrics()
        val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels / 2
        val h = metrics.heightPixels / 2

        imageReader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        virtualDisplay = projection?.createVirtualDisplay(
            "nova_scan", w, h, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, null)

        // give the display a moment to render a frame, then grab it
        Handler(Looper.getMainLooper()).postDelayed({
            val jpeg = grabFrame()
            cleanup()
            if (jpeg == null) {
                onResult?.invoke("I couldn't capture the screen. Try again.")
                stopSelf()
                return@postDelayed
            }
            thread {
                val key = getSharedPreferences("nova", MODE_PRIVATE)
                    .getString("gemini_key", "") ?: ""
                val b64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
                val reply = GeminiClient.askWithImage(key, prompt, b64)
                onResult?.invoke(reply)
                stopSelf()
            }
        }, 800)
        return START_NOT_STICKY
    }

    private fun grabFrame(): ByteArray? {
        return try {
            val image = imageReader?.acquireLatestImage() ?: return null
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val bitmap = Bitmap.createBitmap(
                image.width + rowPadding / pixelStride, image.height,
                Bitmap.Config.ARGB_8888)
            bitmap.copyPixelsFromBuffer(buffer)
            image.close()
            val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
            val out = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 70, out)
            out.toByteArray()
        } catch (e: Exception) { null }
    }

    private fun cleanup() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        virtualDisplay = null; imageReader = null; projection = null
    }

    override fun onDestroy() { cleanup(); super.onDestroy() }

    private fun startInForeground() {
        val channelId = "nova_scan"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                channelId, "Screen scan", NotificationManager.IMPORTANCE_LOW))
        }
        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId)
        else @Suppress("DEPRECATION") Notification.Builder(this)
        builder.setContentTitle("Nova")
            .setContentText("Scanning your screen...")
            .setSmallIcon(R.drawable.ic_launcher)
        val notification: Notification = builder.build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notification)
        }
    }
}
