package com.nova.assistant

import ai.picovoice.porcupine.Porcupine
import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.concurrent.thread

/**
 * Always-listening "Nova" wake word, powered by Picovoice Porcupine
 * (works fully offline once set up).
 *
 * Setup (one time):
 *  1. Create a free account at https://console.picovoice.ai
 *  2. Train a custom keyword "Nova" for Android, download the .ppn file
 *  3. Rename it to "nova.ppn" and put it in: app/src/main/assets/
 *  4. Paste your Picovoice Access Key in the app's key field
 *
 * IMPORTANT: call pause() while Nova is listening/speaking, resume() after.
 * Two things grabbing the mic at once = "he pauses and doesn't answer".
 */
class WakeWordManager(
    private val context: Context,
    private val accessKey: String,
    private val onWake: () -> Unit,
    private val onError: (String) -> Unit
) {
    private var porcupine: Porcupine? = null
    private var recorder: AudioRecord? = null
    @Volatile private var running = false
    @Volatile private var paused = false

    /** Stop reacting to the wake word (mic still held, but ignored). */
    fun pause() { paused = true }

    /** Start reacting to the wake word again. */
    fun resume() { paused = false }

    fun start() {
        thread {
            try {
                porcupine = Porcupine.Builder()
                    .setAccessKey(accessKey)
                    .setKeywordPath("nova.ppn")
                    .build(context)
                val p = porcupine ?: return@thread

                val minBuffer = AudioRecord.getMinBufferSize(
                    16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                recorder = AudioRecord(
                    MediaRecorder.AudioSource.MIC, 16000,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    minBuffer.coerceAtLeast(p.frameLength * 2))
                val r = recorder ?: return@thread
                r.startRecording()
                running = true

                val buffer = ShortArray(p.frameLength)
                while (running) {
                    val read = r.read(buffer, 0, buffer.size)
                    if (read == buffer.size && !paused && p.process(buffer) >= 0) {
                        onWake()
                    }
                }
            } catch (e: Exception) {
                onError("wake word unavailable (" + (e.message ?: "error") + ")")
            }
        }
    }

    fun stop() {
        running = false
        try { recorder?.stop(); recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { porcupine?.delete() } catch (_: Exception) {}
        porcupine = null
    }
}
