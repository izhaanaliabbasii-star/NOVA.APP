package com.nova.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * "play [query]" -> looks up the top YouTube result via the official
 * YouTube Data API (needs a free key from https://console.cloud.google.com,
 * enable "YouTube Data API v3") and opens THAT exact video so it starts
 * playing immediately, instead of just showing a search results list.
 */
object YoutubeClient {

    fun playTop(ctx: Context, query: String): String {
        val key = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
            .getString("youtube_key", "") ?: ""

        if (key.isBlank()) {
            // no key configured -> fall back to opening search results
            return searchFallback(ctx, query, "Add a YouTube API key in Nova to have me play the video directly next time.")
        }

        val videoId = try {
            val url = "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
                "&maxResults=1&q=" + Uri.encode(query) + "&key=" + key
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            if (conn.responseCode != 200) {
                conn.disconnect()
                return searchFallback(ctx, query, "The YouTube key didn't work, so I opened search instead — check the key.")
            }
            val body = conn.inputStream.bufferedReader().readText()
            conn.disconnect()
            val items = JSONObject(body).getJSONArray("items")
            if (items.length() == 0) return "I couldn't find a video for $query."
            items.getJSONObject(0).getJSONObject("id").getString("videoId")
        } catch (e: Exception) {
            return searchFallback(ctx, query, "Couldn't reach YouTube's search API, opening results instead.")
        }

        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=$videoId"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            "Playing $query."
        } catch (e: ActivityNotFoundException) {
            "Found it, but couldn't open a YouTube player."
        }
    }

    private fun searchFallback(ctx: Context, query: String, note: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SEARCH).apply {
                setPackage("com.google.android.youtube")
                putExtra(Intent.EXTRA_QUERY, query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            note
        } catch (e: ActivityNotFoundException) {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            note
        }
    }
}
